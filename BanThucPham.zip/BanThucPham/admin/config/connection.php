<?php
// Thông số kết nối cơ sở dữ liệu
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Thay bằng mật khẩu của bạn nếu có
define('DB_NAME', 'banthucpham');

// Tạo kết nối
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Kiểm tra kết nối
if ($mysqli->connect_error) {
    die("Kết nối thất bại: " . $mysqli->connect_error);
}
// Đặt charset để hỗ trợ tiếng Việt
$mysqli->set_charset("utf8mb4");
?>