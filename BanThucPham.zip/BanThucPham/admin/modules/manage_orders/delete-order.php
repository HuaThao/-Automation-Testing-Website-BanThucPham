<?php
// Include file kết nối
require_once 'C:/xampp/htdocs/BanThucPham/admin/config/connection.php';

// Kiểm tra biến $mysqli
if (!isset($mysqli) || $mysqli->connect_error) {
    die("Lỗi: Kết nối cơ sở dữ liệu không được khởi tạo. " . $mysqli->connect_error);
}

if (isset($_GET['delete_id'])) {
    // Lấy giá trị delete_id đúng cách
    $delete_id = intval($_GET['delete_id']);
    echo "<p>Debug: Đang xử lý xóa đơn hàng ID: $delete_id</p>";

    // Bắt đầu transaction
    $mysqli->begin_transaction();
    
    try {
        // Xóa chi tiết đơn hàng
        $delete_details_sql = "DELETE FROM chitietdonhang WHERE ID_DonHang = ?";
        if ($stmt_details = $mysqli->prepare($delete_details_sql)) {
            $stmt_details->bind_param("i", $delete_id);
            if ($stmt_details->execute()) {
                echo "<p>Debug: Đã xóa " . $stmt_details->affected_rows . " dòng từ chitietdonhang</p>";
            } else {
                echo "<p>Debug: Lỗi xóa chitietdonhang: " . $stmt_details->error . "</p>";
            }
            $stmt_details->close();
        } else {
            echo "<p>Debug: Lỗi chuẩn bị xóa chitietdonhang: " . $mysqli->error . "</p>";
        }

        // Xóa đơn hàng
        $delete_sql = "DELETE FROM donhang WHERE ID_DonHang = ?";
        if ($stmt = $mysqli->prepare($delete_sql)) {
            $stmt->bind_param("i", $delete_id);
            if ($stmt->execute()) {
                echo "<p>Debug: Đã xóa " . $stmt->affected_rows . " dòng từ donhang</p>";
                $mysqli->commit();
                // Redirect về trang danh sách đơn hàng
                header("Location: http://localhost/BanThucPham/admin/index.php?order=order-list&status=deleted");
                exit();
            } else {
                throw new Exception("Lỗi thực thi xóa đơn hàng: " . $stmt->error);
            }
            $stmt->close();
        } else {
            throw new Exception("Lỗi chuẩn bị câu lệnh xóa donhang: " . $mysqli->error);
        }
    } catch (Exception $e) {
        $mysqli->rollback();
        echo "<p>Lỗi: " . $e->getMessage() . "</p>";
        echo "<p>Debug: Transaction đã rollback</p>";
        exit(); // Dừng để xem lỗi
    }
}
?>