<?php
// Bắt đầu session để lưu thông báo
session_start();

// Include the configuration file to define BASE_PATH and database connection
require_once 'C:/xampp/htdocs/BanThucPham/admin/config/connection.php';

// Bật hiển thị lỗi để debug
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Kiểm tra biến $mysqli
if (!isset($mysqli)) {
    die("Lỗi: Kết nối cơ sở dữ liệu không được khởi tạo.");
}

// Lấy ID đơn hàng từ URL và kiểm tra
$id_order = isset($_GET['id']) ? $_GET['id'] : '';
if (!is_numeric($id_order) || $id_order <= 0) {
    die("Lỗi: ID đơn hàng không hợp lệ.");
}

// Xử lý duyệt đơn hàng
if (isset($_POST['approve_order'])) {
    // Kiểm tra lại $id_order để đảm bảo an toàn
    if (!is_numeric($id_order) || $id_order <= 0) {
        die("Lỗi: ID đơn hàng không hợp lệ khi duyệt.");
    }

    $update_sql = "UPDATE donhang SET XuLy = 2 WHERE ID_DonHang = ?"; // Cập nhật XuLy thành 2 (Đã duyệt)
    $update_stmt = $mysqli->prepare($update_sql);
    if (!$update_stmt) {
        die("Lỗi chuẩn bị câu truy vấn: " . $mysqli->error);
    }
    $update_stmt->bind_param("i", $id_order);
    
    if ($update_stmt->execute()) {
        // Lưu thông báo vào session
        $_SESSION['message'] = "Đơn hàng đã được duyệt thành công!";
        $_SESSION['message_type'] = "success";
        
        // Duyệt thành công, làm mới trang chi tiết đơn hàng (bỏ tham số success)
        header("Location: order-detail.php?id=" . $id_order);
        exit();
    } else {
        // Hiển thị lỗi nếu cập nhật thất bại
        die("Lỗi khi duyệt đơn hàng: " . $update_stmt->error);
    }
    $update_stmt->close();
}

// Truy vấn thông tin đơn hàng bằng prepared statement
$sql_order = "SELECT NguoiNhan, SoDienThoai, DiaChi, ThoiGianLap, GhiChu, 
              CodeOrder, HinhThucThanhToan, GiaTien, XuLy 
              FROM donhang WHERE ID_DonHang = ?";
$stmt = $mysqli->prepare($sql_order);
if (!$stmt) {
    die("Lỗi chuẩn bị câu truy vấn: " . $mysqli->error);
}
$stmt->bind_param("i", $id_order);
$stmt->execute();
$query_order = $stmt->get_result();

if (!$query_order || $query_order->num_rows == 0) {
    die("Lỗi: Không tìm thấy đơn hàng với ID $id_order.");
}
$row = $query_order->fetch_assoc();

// Chuyển đổi HinhThucThanhToan
$hinhThucThanhToan = $row['HinhThucThanhToan'];
if (strtoupper($hinhThucThanhToan) === 'COD') {
    $hinhThucThanhToan = 'Thanh toán khi nhận hàng';
}

// Truy vấn chi tiết đơn hàng
$sql_order_detail = "SELECT sanpham.TenSanPham, sanpham.Img, chitietdonhang.SoLuong, chitietdonhang.GiaMua 
                     FROM sanpham 
                     INNER JOIN chitietdonhang ON chitietdonhang.ID_SanPham = sanpham.ID_SanPham 
                     WHERE chitietdonhang.ID_DonHang = ?";
$stmt_detail = $mysqli->prepare($sql_order_detail);
if (!$stmt_detail) {
    die("Lỗi chuẩn bị câu truy vấn: " . $mysqli->error);
}
$stmt_detail->bind_param("i", $id_order);
$stmt_detail->execute();
$query_order_detail = $stmt_detail->get_result();

if (!$query_order_detail) {
    die("Lỗi truy vấn chi tiết đơn hàng: " . $mysqli->error);
}

// Tính tổng số lượng và tổng tiền
$total_quantity = 0;
$total_price = 0;
$query_order_detail->data_seek(0); // Reset con trỏ về đầu
while ($row_detail = $query_order_detail->fetch_assoc()) {
    $total_quantity += $row_detail['SoLuong'];
    $total_price += $row_detail['SoLuong'] * $row_detail['GiaMua'];
}
$query_order_detail->data_seek(0); // Reset lại con trỏ để sử dụng trong vòng lặp hiển thị
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết đơn hàng</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            background-color: #f5f5f5; 
        }
        .container { 
            max-width: 1000px; 
            margin: 0 auto; 
        }
        h1 { 
            text-align: center; 
            color: #333; 
            margin-bottom: 20px; 
        }
        .card { 
            background-color: #fff; 
            padding: 20px; 
            border-radius: 8px; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
        }
        th, td { 
            padding: 12px; 
            border: 1px solid #ddd; 
        }
        th { 
            background-color: #007bff; 
            color: white; 
            text-align: center; 
        }
        td { 
            background-color: #fff; 
            text-align: center; 
        }
        .total { 
            font-weight: bold; 
            text-align: right; 
            background-color: #f8f9fa; 
        }
        .product-image { 
            width: 80px; 
            height: 80px; 
            object-fit: cover; 
            border-radius: 8px; 
            border: 2px solid #ddd; 
            box-shadow: 0 2px 4px rgba(0,0,0,0.1); 
            transition: transform 0.3s ease; 
        }
        .product-image:hover { 
            transform: scale(1.1); 
        }
        .action-section {
            text-align: center;
            margin-top: 20px;
        }
        .approve-btn {
            background: linear-gradient(45deg, #28a745, #34c759);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        .approve-btn:hover {
            background: linear-gradient(45deg, #218838, #2db84c);
            transform: translateY(-2px);
            box-shadow: 0 6px 10px rgba(0,0,0,0.15);
        }
        .back-btn {
            background: linear-gradient(135deg, #6c757d, #adb5bd);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            box-shadow: 0 4px 10px rgba(108, 117, 125, 0.3);
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        .back-btn:hover {
            background: linear-gradient(135deg, #5a6268, #969fa8);
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(108, 117, 125, 0.4);
        }
        /* CSS cho trạng thái đơn hàng */
        .status-display {
            text-align: center;
            padding: 12px;
            margin: 15px 0;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            display: block; /* Luôn hiển thị */
        }
        .approved {
            background: #e9ecef;
            color: #212529;
            border: 1px solid #dee2e6;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .canceled {
            background: linear-gradient(45deg, #f8d7da, #f5c6cb);
            color: #721c24;
            border: 1px solid #f5c6cb;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        /* Toast Notification (Thông báo góc phải) */
.toast {
    position: fixed;
    top: 80px;
    right: 20px;
    z-index: 1000;
    visibility: hidden;
    min-width: 250px;
    padding: 14px;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
    transition: all 0.3s ease;
}

.toast.show {
    visibility: visible;
    opacity: 1;
}

.toast-message {
    font-size: 15px;
    color: #fff;
    text-align: center;
}

.toast.success {
    background-color: #28a745;
}
    </style>
</head>
<body>
<div id="toast" class="toast">
        <div id="toastMessage" class="toast-message"></div>
    </div>
    <div class="container">
        <div class="card">
            <table>
                <tr>
                    <th colspan="5"><h1>Chi tiết đơn hàng</h1></th>
                </tr>
                <tr>
                    <td colspan="2"><strong>Người nhận:</strong> <?= htmlspecialchars($row['NguoiNhan']) ?></td>
                    <td colspan="3"><strong>Số điện thoại:</strong> <?= htmlspecialchars($row['SoDienThoai']) ?></td>
                </tr>
                <tr>
                    <td colspan="2"><strong>Địa chỉ:</strong> <?= htmlspecialchars($row['DiaChi']) ?></td>
                    <td colspan="3"><strong>Ghi chú:</strong> <?= htmlspecialchars($row['GhiChu']) ?></td>
                </tr>
                <tr>
                    <th>STT</th>
                    <th>Ảnh</th>
                    <th>Tên sản phẩm</th>
                    <th>Số lượng</th>
                    <th>Giá bán</th>
                </tr>
                <?php 
                $i = 0;
                while ($row_detail = $query_order_detail->fetch_assoc()) {
                    $i++;
                ?>
                <tr>
                    <td><?= $i ?></td>
                    <td>
                        <img class="product-image"
                             src="/BanThucPham/assets/image/product/<?php echo $row_detail['Img'];?>"/>
                    </td>
                    <td><?= htmlspecialchars($row_detail['TenSanPham']) ?></td>
                    <td><?= htmlspecialchars($row_detail['SoLuong']) ?></td>
                    <td><?= number_format($row_detail['GiaMua'], 0, ',', '.') ?> VND/Kg</td>
                </tr>
                <?php } ?>
                <tr>          
                    <td colspan="5" class="total">
                        Tổng tiền: <?= number_format($total_price, 0, ',', '.') ?> VND<br>
                    </td>
                </tr>
            </table>

            <!-- Thêm phần tử để hiển thị thông báo động -->
            <div id="success-message" class="success"></div>

            <!-- Hiển thị trạng thái đơn hàng và button duyệt -->
            <div class="action-section">
                <div class="status-display 
                    <?= $row['XuLy'] == 2 ? 'approved' : ($row['XuLy'] == 1 ? 'canceled' : '') ?>">
                    <?php 
                    if ($row['XuLy'] == 2) {
                        echo "Đơn hàng đã được duyệt.";
                    } elseif ($row['XuLy'] == 1) {
                        echo "Đơn hàng đã bị hủy.";
                    } else { // XuLy = 0
                    ?>
                        <form method="POST" action="">
                            <button type="submit" name="approve_order" class="approve-btn">Duyệt đơn hàng</button>
                        </form>
                    <?php } ?>
                    </div>
                <!-- Thêm nút Quay lại -->
                <a href="http://localhost/BanThucPham/admin/index.php?order=order-list" class="back-btn">Quay lại</a>
            </div>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript để hiển thị thông báo và tải lại trang -->
    <script>
        // Hàm hiển thị thông báo
        
        function showMessage(message, type) {
        var toast = document.getElementById("toast");
        var toastMessage = document.getElementById("toastMessage");
        if (toast && toastMessage) {
            toastMessage.textContent = message;
            toast.className = "toast show " + type;
            setTimeout(function() {
                toast.className = toast.className.replace("show", "");
            }, 3000);
        } else {
            console.error("Không tìm thấy phần tử toast");
        }
    }

        // Kiểm tra nếu có thông báo trong session
        window.onload = function() {
            <?php if (isset($_SESSION['message'])): ?>
                showMessage("<?= $_SESSION['message'] ?>", "<?= $_SESSION['message_type'] ?>", function() {
                    // Tải lại trang sau khi thông báo biến mất
                    window.location.href = window.location.pathname + '?id=<?= $id_order ?>';
                });
                <?php
                // Xóa thông báo sau khi hiển thị
                unset($_SESSION['message']);
                unset($_SESSION['message_type']);
                ?>
            <?php endif; ?>
        };
    </script>

    <?php
    // Giải phóng tài nguyên
    $stmt->close();
    $stmt_detail->close();
    $mysqli->close();
    ?>
</body>
</html>