<?php
// Bật hiển thị lỗi
error_reporting(E_ALL);
ini_set('display_errors', 1);
ob_start(); // Ngăn lỗi headers already sent

// Include file kết nối
require_once 'C:/xampp/htdocs/BanThucPham/admin/config/connection.php';

// Kiểm tra biến $mysqli
if (!isset($mysqli) || $mysqli->connect_error) {
    die("Lỗi: Kết nối cơ sở dữ liệu không được khởi tạo. " . $mysqli->connect_error);
}
// Xử lý yêu cầu xóa đơn hàng


// Truy vấn danh sách đơn hàng
$sql = "SELECT ID_DonHang, ID_ThanhVien, ThoiGianLap, XuLy 
        FROM donhang 
        ORDER BY ThoiGianLap DESC";
$result = $mysqli->query($sql);
if (!$result) {
    echo "<p>Lỗi truy vấn danh sách: " . $mysqli->error . "</p>";
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách đơn hàng</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            background-color: #f5f7fa; 
        }
        h1 { 
            text-align: center; 
            color: #333; 
            font-size: 28px; 
            margin-bottom: 30px; 
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 20px; 
            background-color: #fff; 
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); 
        }
        th, td { 
            border: 1px solid #ddd; 
            padding: 12px; 
            text-align: left; 
        }
        th { 
            background-color: #007bff; 
            color: white; 
            font-weight: 600; 
            text-transform: uppercase; 
        }
        tr:nth-child(even) { 
            background-color: #f2f2f2; 
        }
        tr:hover { 
            background-color: #e9ecef; 
        }
        .detail-link, .delete-link { 
            text-decoration: none; 
            padding: 8px 16px; 
            border-radius: 5px; 
            font-size: 14px; 
            font-weight: 500; 
            transition: all 0.3s ease; 
            display: inline-block; 
            margin-right: 8px; 
        }
        .detail-link { 
            background-color: #007bff; 
            color: white; 
            border: 1px solid #007bff; 
        }
        .detail-link:hover { 
            background-color: #0056b3; 
            border-color: #0056b3; 
            transform: translateY(-2px); 
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2); 
        }
        .delete-link { 
            background-color: #dc3545; 
            color: white; 
            border: 1px solid #dc3545; 
        }
        .delete-link:hover { 
            background-color: #a71d2a; 
            border-color: #a71d2a; 
            transform: translateY(-2px); 
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2); 
        }
        .toast {
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 1000;
            visibility: hidden;
            min-width: 250px;
            padding: 14px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }
        .toast.show {
            visibility: visible;
            opacity: 1;
        }
        .toast-message {
            font-size: 15px;
            color: #fff;
            text-align: center;
        }
        .toast.success {
            background-color: #28a745;
        }
    </style>
</head>
<body>
    <h1>Danh sách đơn hàng</h1>
    <div id="toast" class="toast">
        <div id="toastMessage" class="toast-message"></div>
    </div>

    <?php
    if ($result && $result->num_rows > 0) {
        echo "<table>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>ID Đơn hàng</th>";
        echo "<th>Thời gian đặt</th>";
        echo "<th>Tình trạng đơn hàng</th>";
        echo "<th>Tình trạng thanh toán</th>"; // Thêm cột mới
        echo "<th>Tùy chọn</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['ID_DonHang']) . "</td>";
            echo "<td>" . htmlspecialchars($row['ThoiGianLap']) . "</td>";
            echo "<td>";
            switch ($row['XuLy']) {
                case 0: echo "Chưa duyệt"; break;
                case 1: echo "Đã hủy"; break;
                default: echo "Đã duyệt";
            }
            echo "</td>";
            // Thêm cột Tình trạng thanh toán
        echo "<td>";
        switch ($row['XuLy']) {
            case 2: echo "Đã thanh toán"; break; // Đã duyệt
            default: echo "Chưa thanh toán"; // Chưa duyệt hoặc Đã hủy
        }
            echo "<td>";
            echo "<a href='modules/manage_orders/order-detail.php?id=" . $row['ID_DonHang'] . "' class='detail-link'>Xem chi tiết</a>";
            // Bỏ confirm trong nút Xóa
            echo "<a href='#' class='delete-link' onclick='showConfirmModal(" . $row['ID_DonHang'] . ")'>Xóa</a>";
            echo "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>Không có dữ liệu trong bảng đơn hàng hoặc lỗi truy vấn.</p>";
    }
    

    if ($result) $result->free();
    $mysqli->close();
    ?>
<!-- Hộp thoại xác nhận xóa -->
<div id="confirmModal" class="modal">
    <div class="modal-content">
        <div class="warning-icon">!</div>
        <h3>Xác nhận xóa đơn hàng?</h3>
        <p>Bạn có chắc chắn muốn xóa đơn hàng này?</p>
        <div class="button-container">
            <button id="confirmDelete" class="btn btn-confirm">Xóa</button>
            <button id="cancelDelete" class="btn btn-cancel">Hủy</button>
        </div>
    </div>
</div>
</div>
</div>
</body>
</html>
<style>
 /* CSS cho hộp thoại xác nhận */
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.6);
    justify-content: center;
    align-items: center;
    animation: fadeIn 0.3s ease-in-out;
}

.modal-content {
    background-color: #ffffff;
    padding: 25px;
    border-radius: 12px;
    text-align: center;
    width: 350px;
    max-width: 90%;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    position: relative;
    animation: slideIn 0.3s ease-out;
}

/* Hiệu ứng mờ dần cho nền */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* Hiệu ứng trượt từ trên xuống cho modal */
@keyframes slideIn {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

/* Biểu tượng cảnh báo với hiệu ứng động */
.modal-content .warning-icon {
    font-size: 40px;
    color: #ff6f61;
    margin-bottom: 15px;
    display: inline-block;
    animation: pulse 1.5s infinite ease-in-out;
}

/* Hiệu ứng nhấp nháy cho biểu tượng */
@keyframes pulse {
    0% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.2); opacity: 0.7; }
    100% { transform: scale(1); opacity: 1; }
}

/* Tiêu đề của modal */
.modal-content h3 {
    margin: 0 0 10px;
    font-size: 20px;
    font-weight: 600;
    color: #2d3748;
}

/* Đoạn văn mô tả */
.modal-content p {
    margin: 0 0 25px;
    font-size: 15px;
    color: #4a5568;
    line-height: 1.5;
}

/* Container cho các nút */
.modal-content .button-container {
    display: flex;
    justify-content: center;
    gap: 20px; /* Tăng khoảng cách giữa hai nút */
}

/* Nút chung */
.modal-content .btn {
    padding: 12px 40px; /* Tăng chiều rộng nút để giống hình */
    border: none;
    border-radius: 8px; /* Bo góc nhẹ hơn */
    cursor: pointer;
    font-size: 16px;
    font-weight: 500;
    transition: all 0.3s ease;
}

/* Nút Xóa */
.modal-content .btn-confirm {
    background-color: #ff4d4f; /* Màu đỏ giống hình */
    color: white;
}

.modal-content .btn-confirm:hover {
    background-color: #e63946;
    transform: translateY(-2px);
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
}

/* Nút Hủy */
.modal-content .btn-cancel {
    background-color: #6c757d; /* Màu xám giống hình */
    color: white;
}

.modal-content .btn-cancel:hover {
    background-color: #5a6268;
    transform: translateY(-2px);
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
}

/* Hiệu ứng mờ dần khi đóng */
@keyframes fadeOut {
    from { opacity: 1; }
    to { opacity: 0; }
}

/* Responsive cho màn hình nhỏ */
@media (max-width: 480px) {
    .modal-content {
        width: 90%;
        padding: 20px;
    }

    .modal-content h3 {
        font-size: 18px;
    }

    .modal-content p {
        font-size: 14px;
    }

    .modal-content .btn {
        padding: 10px 30px;
        font-size: 14px;
    }

    .modal-content .warning-icon {
        font-size: 35px;
    }

    .modal-content .button-container {
        gap: 15px; /* Giảm khoảng cách trên màn hình nhỏ */
    }
}
/* Reset và container */
body {
    font-family: 'Roboto', Arial, sans-serif;
    background-color: #f5f7fa;
    margin: 0;
    padding: 0;
    color: #333;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 40px 20px;
    min-height: calc(100vh - 120px);
    position: relative; /* Để toast có thể định vị chính xác */
}

/* Tiêu đề */
.order-detail-title {
    text-align: center;
    font-size: 32px;
    font-weight: 700;
    color: #1a2526;
    margin-bottom: 40px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

/* Card thông tin đơn hàng */
.order-info-card {
    background-color: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    margin-bottom: 30px;
    transition: transform 0.3s ease;
}

.order-info-card:hover {
    transform: translateY(-5px);
}

.order-info-card .card-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #e0e0e0;
    padding: 20px;
}

.order-info-card .card-title {
    margin: 0;
    font-size: 20px;
    font-weight: 600;
    color: #1a2526;
}

.order-info-card .card-body {
    padding: 30px;
}

.info-section {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.info-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 10px 0;
    border-bottom: 1px solid #e0e0e0;
}

.info-label {
    font-weight: 600;
    color: #4a5568;
    font-size: 16px;
    min-width: 150px;
}

.info-value {
    color: #2d3748;
    font-size: 16px;
    font-weight: 400;
}

/* Card danh sách sản phẩm */
.product-list-card {
    background-color: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    margin-bottom: 30px;
    transition: transform 0.3s ease;
}

.product-list-card:hover {
    transform: translateY(-5px);
}

.product-list-card .card-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #e0e0e0;
    padding: 20px;
}

.product-list-card .card-title {
    margin: 0;
    font-size: 20px;
    font-weight: 600;
    color: #1a2526;
}

.product-list-card .card-body {
    padding: 20px;
}

.product-table-wrapper {
    max-height: 150px; /* Giảm chiều cao để thanh cuộn xuất hiện sớm hơn */
    overflow-y: auto; /* Thanh cuộn dọc */
    overflow-x: auto; /* Thanh cuộn ngang nếu cần */
}

.table {
    margin-bottom: 0;
    width: 100%;
}

.table th, .table td {
    padding: 15px; /* Đảm bảo padding đủ lớn để mỗi hàng có chiều cao phù hợp */
    vertical-align: middle;
    font-size: 16px;
    text-align: center; /* Căn giữa chữ trong tất cả các cột */
    min-height: 50px; /* Đảm bảo chiều cao tối thiểu cho mỗi hàng */
}

.table tbody tr {
    height: 50px; /* Đặt chiều cao cố định cho mỗi hàng */
}

.table th {
    background-color: #007bff;
    color: #fff;
    font-weight: 600;
    text-transform: uppercase;
    position: sticky;
    top: 0;
    z-index: 1;
}

/* Độ rộng cố định cho các cột */
.table th.col-stt, .table td.col-stt {
    width: 10%;
}

.table th.col-product-name, .table td.col-product-name {
    width: 40%;
}

.table th.col-quantity, .table td.col-quantity {
    width: 20%;
}

.table th.col-price, .table td.col-price {
    width: 30%;
}

.table-striped tbody tr:nth-of-type(odd) {
    background-color: #f8f9fa;
}

.table-hover tbody tr:hover {
    background-color: #e9ecef;
}

.total-price {
    text-align: right;
    margin-top: 20px;
    font-size: 18px;
    font-weight: 700;
    color: #1a2526;
}

.total-label {
    margin-right: 10px;
    color: #4a5568;
}

.total-value {
    color: #e74c3c;
}

/* Nút Hủy đơn hàng */
.btn-cancel-order {
    background-color: #e74c3c;
    color: #fff;
    padding: 12px 30px;
    font-size: 16px;
    font-weight: 600;
    border-radius: 6px;
    text-transform: uppercase;
    text-decoration: none;
    transition: background-color 0.3s ease, transform 0.3s ease;
    display: inline-block;
}

.btn-cancel-order:hover {
    background-color: #c0392b;
    transform: translateY(-2px);
}

/* Toast Notification (Thông báo góc phải) */
.toast {
    position: fixed;
    top: 80px;
    right: 20px;
    z-index: 1000;
    visibility: hidden;
    min-width: 250px;
    padding: 14px;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
    transition: all 0.3s ease;
}

.toast.show {
    visibility: visible;
    opacity: 1;
}

.toast-message {
    font-size: 15px;
    color: #fff;
    text-align: center;
}

.toast.success {
    background-color: #28a745;
}

/* Responsive */
@media (max-width: 768px) {
    .container {
        padding: 20px 10px;
    }

    .order-detail-title {
        font-size: 26px;
        margin-bottom: 30px;
    }

    .order-info-card .card-body {
        padding: 20px;
    }

    .info-section {
        gap: 10px;
    }

    .info-label, .info-value {
        font-size: 14px;
    }

    .info-label {
        min-width: 120px;
    }

    .product-list-card .card-header {
        padding: 15px;
    }

    .product-list-card .card-title {
        font-size: 18px;
    }

    .product-list-card .card-body {
        padding: 15px;
    }

    .table th, .table td {
        padding: 10px;
        font-size: 14px;
    }

    .table tbody tr {
        height: 40px; /* Giảm chiều cao trên di động */
    }

    .product-table-wrapper {
        max-height: 120px; /* Giảm chiều cao trên di động */
    }

    .total-price {
        font-size: 16px;
    }

    .btn-cancel-order {
        padding: 10px 20px;
        font-size: 14px;
    }

    .toast {
        top: 60px;
        right: 10px;
        min-width: 200px;
        padding: 10px;
    }
}
</style>

<script>
// Hiển thị hộp thoại xác nhận
function showConfirmModal(orderId) {
    const modal = document.getElementById("confirmModal");
    const confirmButton = document.getElementById("confirmDelete");
    const cancelButton = document.getElementById("cancelDelete");

    // Hiển thị modal
    modal.style.display = "flex";

    // Xử lý khi nhấn nút "Xóa"
    confirmButton.onclick = function() {
        window.location.href = 'modules/manage_orders/delete-order.php?delete_id=' + orderId;
    };

    // Xử lý khi nhấn nút "Hủy"
    cancelButton.onclick = function() {
        modal.style.animation = "fadeOut 0.3s ease-in-out";
        setTimeout(() => {
            modal.style.display = "none";
            modal.style.animation = ""; // Reset animation để lần sau mở lại đúng
        }, 300);
    };
}

// Đóng modal nếu người dùng nhấn ra ngoài modal
window.onclick = function(event) {
    const modal = document.getElementById("confirmModal");
    if (event.target === modal) {
        modal.style.animation = "fadeOut 0.3s ease-in-out";
        setTimeout(() => {
            modal.style.display = "none";
            modal.style.animation = ""; // Reset animation
        }, 300);
    }
};
document.addEventListener("DOMContentLoaded", function() {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('status') === 'deleted') {
            // Hiển thị thông báo
            showMessage("Đã xóa đơn hàng thành công", "success");

            // Xóa tham số status khỏi URL mà không tải lại trang
            urlParams.delete('status');
            const newUrl = window.location.pathname + '?' + urlParams.toString();
            window.history.replaceState({}, document.title, newUrl);
        }
    });

    function showMessage(message, type) {
        var toast = document.getElementById("toast");
        var toastMessage = document.getElementById("toastMessage");
        if (toast && toastMessage) {
            toastMessage.textContent = message;
            toast.className = "toast show " + type;
            setTimeout(function() {
                toast.className = toast.className.replace("show", "");
            }, 3000);
        } else {
            console.error("Không tìm thấy phần tử toast");
        }
    }
    </script>