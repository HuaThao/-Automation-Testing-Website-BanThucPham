<div>
    <div id="content" class="container-fluid">
        <h1 class="text-center">THỐNG KÊ DOANH THU</h1>
        <div >
            <p class="font-weight-bold">Tuần vừa qua</p>
            <div id="chart3" style="height: 200px;"></div> 
        </div>
        <div style="margin-top: 200px;">
            <p class="font-weight-bold">30 ngày qua</p>
            <div id="chart2" style="height: 200px;"></div> 
        </div>
        <div style="margin-top: 200px;">
            <p class="font-weight-bold">365 ngày qua</p>
            <div id="chart1" style="height: 200px;"></div>
        </div>
    </div>
</div>
